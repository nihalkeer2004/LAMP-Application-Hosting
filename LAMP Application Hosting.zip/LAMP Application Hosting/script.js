// ========================================
// AWS API Gateway URL
// ========================================

const API_BASE =
    "https://wdl02i5m44.execute-api.ap-south-1.amazonaws.com/prod";


// API endpoints

const POST_API = API_BASE + "/notes";

const GET_API = API_BASE + "/notes";


// ========================================
// SAVE NOTE
// ========================================

async function saveNote() {

    const noteBox = document.getElementById("note");

    const note = noteBox.value.trim();


    // Don't save an empty note

    if (note === "") {

        alert("Please write a note first.");

        return;
    }


    try {

        console.log("Sending note to:", POST_API);


        const response = await fetch(POST_API, {

            method: "POST",

            headers: {

                "Content-Type": "application/json"

            },

            body: JSON.stringify({

                note: note

            })

        });


        console.log(
            "POST status:",
            response.status
        );


        if (!response.ok) {

            throw new Error(
                "HTTP Error: " + response.status
            );
        }


        const data = await response.json();


        console.log(
            "Save response:",
            data
        );


        alert("Note saved successfully!");


        // Clear textarea

        noteBox.value = "";


        // Reload notes

        loadNotes();


    } catch (error) {

        console.error(
            "Save error:",
            error
        );


        alert(
            "Failed to save note.\n\n" +
            "Check the browser console."
        );
    }
}


// ========================================
// LOAD NOTES
// ========================================

async function loadNotes() {

    const notesContainer =
        document.getElementById("notes");


    try {

        console.log(
            "Loading notes from:",
            GET_API
        );


        notesContainer.innerHTML = `
            <p class="loading">
                Loading notes...
            </p>
        `;


        const response = await fetch(GET_API);


        console.log(
            "GET status:",
            response.status
        );


        if (!response.ok) {

            throw new Error(
                "HTTP Error: " + response.status
            );
        }


        const data = await response.json();


        console.log(
            "Notes received:",
            data
        );


        // Check whether notes exist

        if (
            !Array.isArray(data) ||
            data.length === 0
        ) {

            notesContainer.innerHTML = `
                <p class="empty">
                    No notes saved yet.
                </p>
            `;

            return;
        }


        // Create HTML

        let html = "";


        data.forEach(function(note) {

            html += `
                <div class="note">
                    <pre>${escapeHTML(note)}</pre>
                </div>
            `;

        });


        notesContainer.innerHTML = html;


    } catch (error) {

        console.error(
            "Load error:",
            error
        );


        notesContainer.innerHTML = `
            <p class="error">
                Unable to load notes.
            </p>
        `;
    }
}


// ========================================
// SECURITY FUNCTION
// ========================================

function escapeHTML(text) {

    const div =
        document.createElement("div");


    div.textContent = text;


    return div.innerHTML;
}


// ========================================
// LOAD NOTES WHEN PAGE OPENS
// ========================================

window.addEventListener(
    "DOMContentLoaded",
    function() {

        loadNotes();

    }
);